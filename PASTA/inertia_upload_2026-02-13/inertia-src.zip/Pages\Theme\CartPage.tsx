import React from 'react';
import { Head, usePage } from '@inertiajs/react';
import { ThemeProvider } from '@/contexts/ThemeContext';
import { StoreLayout } from '@/components/store/StoreLayout';

export default function CartPage() {
  const { theme, storeName } = usePage().props as any;

  return (
    <>
      <Head title={storeName ? `${storeName} — Carrinho` : 'Carrinho'} />
      <ThemeProvider initialPublished={theme}>
        <StoreLayout>
          <div className="container mx-auto px-4 py-8">
            <h1 className="text-2xl font-bold mb-4">Carrinho</h1>
            <p className="text-muted-foreground">Carrinho client-side (localStorage) será integrado nesta etapa.</p>
          </div>
        </StoreLayout>
      </ThemeProvider>
    </>
  );
}
