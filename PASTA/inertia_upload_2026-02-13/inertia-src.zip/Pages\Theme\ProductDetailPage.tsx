import React from 'react';
import { Head, usePage } from '@inertiajs/react';
import { ThemeProvider } from '@/contexts/ThemeContext';
import { StoreLayout } from '@/components/store/StoreLayout';
import { ProductCard } from '@/components/store/ProductCard';

export default function ProductDetailPage() {
  const { theme, product, relatedProducts, storeName } = usePage().props as any;

  return (
    <>
      <Head title={product?.name ? `${product.name} — ${storeName ?? ''}` : (storeName ?? 'Produto')} />
      <ThemeProvider initialPublished={theme}>
        <StoreLayout>
          <div className="container mx-auto px-4 py-8">
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <img
                  src={product?.images?.[0]}
                  alt={product?.name}
                  className="w-full rounded-lg border"
                />
              </div>
              <div>
                <h1 className="text-2xl font-bold mb-2">{product?.name}</h1>
                {product?.price != null && (
                  <div className="text-xl font-semibold mb-4">R$ {Number(product.price).toFixed(2)}</div>
                )}
                {product?.description && (
                  <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: product.description }} />
                )}
              </div>
            </div>

            {Array.isArray(relatedProducts) && relatedProducts.length > 0 && (
              <div className="mt-12">
                <h2 className="text-xl font-bold mb-4">Relacionados</h2>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                  {relatedProducts.map((p: any) => (
                    <ProductCard key={p.id ?? p.slug} product={p} />
                  ))}
                </div>
              </div>
            )}
          </div>
        </StoreLayout>
      </ThemeProvider>
    </>
  );
}
