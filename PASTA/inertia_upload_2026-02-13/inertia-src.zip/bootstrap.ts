// minimal bootstrap for Inertia bundle
