import React from 'react';
import { Product } from '@/types';
import { formatCurrency } from '@/lib/format';
import { useTheme } from '@/contexts/ThemeContext';
import { cn } from '@/lib/utils';

interface Props {
  product: Product;
}

const aspectMap: Record<string, string> = {
  '1:1': 'aspect-square',
  '3:4': 'aspect-[3/4]',
  '4:5': 'aspect-[4/5]',
  '2:3': 'aspect-[2/3]',
  '16:9': 'aspect-video',
};

const radiusMap: Record<string, string> = {
  none: 'rounded-none',
  small: 'rounded-sm',
  medium: 'rounded-lg',
  large: 'rounded-xl',
  full: 'rounded-full',
};

const spacingMap: Record<string, string> = {
  compact: 'mt-2 space-y-0.5',
  normal: 'mt-3 space-y-1',
  spacious: 'mt-4 space-y-2',
};

const priceTextMap: Record<string, string> = {
  small: 'text-xs',
  medium: 'text-sm',
  large: 'text-base',
};

export function ProductCard({ product }: Props) {
  const { theme } = useTheme();
  const c: any = theme.productCard ?? {};

  const href = `./product/${encodeURIComponent(product.slug)}`;
  const img = (product.images && product.images[0]) ? product.images[0] : '';

  return (
    <a
      href={href}
      className={cn(
        'group block',
        c.border && 'border border-border',
        radiusMap[c.imageBorderRadius] ?? 'rounded-lg',
        c.hoverShadow && 'hover:shadow-lg transition-shadow'
      )}
    >
      <div
        className={cn(
          'overflow-hidden bg-secondary relative',
          aspectMap[c.imageAspect] || 'aspect-[3/4]',
          radiusMap[c.imageBorderRadius] ?? 'rounded-lg'
        )}
      >
        {img ? (
          <img
            src={img}
            alt={product.name}
            className={cn('h-full w-full object-cover transition-transform duration-500', c.imageHover === 'zoom' ? 'group-hover:scale-105' : '')}
            loading="lazy"
          />
        ) : (
          <div className="h-full w-full" />
        )}
      </div>

      <div className={cn('px-1 pb-2', spacingMap[c.spacing] ?? 'mt-3 space-y-1')}>
        <h3
          className={cn(
            'text-sm font-medium leading-tight',
            c.titleLines === 1 ? 'line-clamp-1' : c.titleLines === 2 ? 'line-clamp-2' : 'line-clamp-3'
          )}
        >
          {product.name}
        </h3>

        <div className={cn('flex items-center gap-2', c.contentAlign === 'center' && 'justify-center')}>
          <span className={cn('font-semibold', priceTextMap[c.priceSize] ?? 'text-sm')}>
            {formatCurrency(product.price)}
          </span>
          {c.showComparePrice && product.compareAtPrice ? (
            <span className="text-xs text-muted-foreground line-through">
              {formatCurrency(product.compareAtPrice)}
            </span>
          ) : null}
        </div>
      </div>
    </a>
  );
}
