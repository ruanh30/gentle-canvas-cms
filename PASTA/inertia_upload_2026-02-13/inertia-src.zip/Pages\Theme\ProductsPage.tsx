import React from 'react';
import { Head, usePage } from '@inertiajs/react';
import { ThemeProvider } from '@/contexts/ThemeContext';
import { StoreLayout } from '@/components/store/StoreLayout';
import { ProductCard } from '@/components/store/ProductCard';

export default function ProductsPage() {
  const { theme, products, categories, currentCategory, storeName } = usePage().props as any;

  return (
    <>
      <Head title={storeName ? `${storeName} — Produtos` : 'Produtos'} />
      <ThemeProvider initialPublished={theme}>
        <StoreLayout>
          <div className="container mx-auto px-4 py-8">
            <h1 className="text-2xl font-bold mb-4">Produtos</h1>

            {Array.isArray(categories) && categories.length > 0 && (
              <div className="mb-6 flex flex-wrap gap-2">
                <a
                  href="./shop"
                  className={`text-sm px-3 py-1 rounded-full border hover:bg-secondary ${!currentCategory ? 'bg-secondary' : ''}`}
                >
                  Todos
                </a>
                {categories.map((c: any) => (
                  <a
                    key={c.slug ?? c.id}
                    href={`./shop?category=${encodeURIComponent(c.slug ?? '')}`}
                    className={`text-sm px-3 py-1 rounded-full border hover:bg-secondary ${currentCategory === (c.slug ?? null) ? 'bg-secondary' : ''}`}
                  >
                    {c.name}
                  </a>
                ))}
              </div>
            )}

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {(products ?? []).map((p: any) => (
                <ProductCard key={p.id ?? p.slug} product={p} />
              ))}
            </div>
          </div>
        </StoreLayout>
      </ThemeProvider>
    </>
  );
}
