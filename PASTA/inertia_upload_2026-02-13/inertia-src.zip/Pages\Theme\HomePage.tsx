import React from 'react';
import { Head, usePage } from '@inertiajs/react';
import { ThemeProvider } from '@/contexts/ThemeContext';
import { StoreLayout } from '@/components/store/StoreLayout';
import { ProductCard } from '@/components/store/ProductCard';

export default function HomePage() {
  const { theme, products, categories, storeName } = usePage().props as any;

  return (
    <>
      <Head title={storeName ? `${storeName}` : 'Loja'} />
      <ThemeProvider initialPublished={theme}>
        <StoreLayout>
          <div className="container mx-auto px-4 py-8">
            {Array.isArray(categories) && categories.length > 0 && (
              <div className="mb-6 flex flex-wrap gap-2">
                {categories.map((c: any) => (
                  <a
                    key={c.slug ?? c.id}
                    href={`./shop?category=${encodeURIComponent(c.slug ?? '')}`}
                    className="text-sm px-3 py-1 rounded-full border hover:bg-secondary"
                  >
                    {c.name}
                  </a>
                ))}
              </div>
            )}

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {(products ?? []).map((p: any) => (
                <ProductCard key={p.id ?? p.slug} product={p} />
              ))}
            </div>
          </div>
        </StoreLayout>
      </ThemeProvider>
    </>
  );
}
