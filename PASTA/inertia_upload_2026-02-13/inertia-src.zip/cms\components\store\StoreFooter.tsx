import React from 'react';
import { useTheme } from '@/contexts/ThemeContext';

export function StoreFooter() {
  const { theme } = useTheme();
  const f: any = theme.footer ?? {};

  return (
    <footer className="mt-12 border-t" style={{ backgroundColor: f.backgroundColor ?? theme.colors.foreground }}>
      <div className="container mx-auto px-4 py-10" style={{ color: f.textColor ?? '#94a3b8' }}>
        <div className="text-sm">{f.copyrightText ?? '© ' + new Date().getFullYear()}</div>
      </div>
    </footer>
  );
}
