import React from 'react';
import { Head, usePage } from '@inertiajs/react';
import { ThemeProvider } from '@/contexts/ThemeContext';
import { StoreLayout } from '@/components/store/StoreLayout';

export default function CheckoutPage() {
  const { theme, storeName } = usePage().props as any;

  return (
    <>
      <Head title={storeName ? `${storeName} — Checkout` : 'Checkout'} />
      <ThemeProvider initialPublished={theme}>
        <StoreLayout>
          <div className="container mx-auto px-4 py-8">
            <h1 className="text-2xl font-bold mb-4">Checkout</h1>
            <p className="text-muted-foreground">Checkout será integrado com pedidos do FlashLoja nesta etapa.</p>
          </div>
        </StoreLayout>
      </ThemeProvider>
    </>
  );
}
