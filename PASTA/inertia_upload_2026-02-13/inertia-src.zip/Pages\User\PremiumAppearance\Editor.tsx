import React from 'react';
import { Head, usePage, router } from '@inertiajs/react';
import { ThemeProvider } from '../../../cms/contexts/ThemeContext';
import { ThemeEditorLayout } from '../../../cms/components/theme-editor/ThemeEditorLayout';

type Props = {
  theme: string;
  draft: any;
  published: any;
  draftVersion: number;
  publishedVersion: number;
  previewUrl: string;
};

export default function Editor() {
  const { props } = usePage<{ props: Props }>() as any;
  const p = (props as any) as Props;

  return (
    <>
      <Head title="Editor Premium" />
      <ThemeProvider
        initialDraft={p.draft}
        initialPublished={p.published}
        onSaveDraft={(config, label) => {
          router.post('/user/site-settings/appearance-premium/save', { config, label }, { preserveScroll: true });
        }}
        onPublish={(label) => {
          router.post('/user/site-settings/appearance-premium/publish', { label }, { preserveScroll: true });
        }}
      >
        <ThemeEditorLayout previewUrl={p.previewUrl} />
      </ThemeProvider>
    </>
  );
}
