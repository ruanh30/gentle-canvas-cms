import React from 'react';
import { useTheme } from '@/contexts/ThemeContext';

export function StoreHeader() {
  const { theme } = useTheme();
  const h: any = theme.header ?? {};

  return (
    <header className="w-full border-b" style={{ backgroundColor: theme.colors.background }}>
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <a href="./" className="font-bold text-lg" style={{ color: theme.colors.foreground }}>
          {h.storeName || 'Loja'}
        </a>
        <nav className="flex items-center gap-4 text-sm" style={{ color: theme.colors.foreground }}>
          <a href="./shop" className="hover:opacity-80">Produtos</a>
          <a href="./cart" className="hover:opacity-80">Carrinho</a>
        </nav>
      </div>
    </header>
  );
}
